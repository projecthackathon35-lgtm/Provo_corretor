from flask import Flask, render_template, request
import pdfplumber
import pytesseract
from PIL import Image

app = Flask(__name__)
# n sei pq tem 2 "erros" ta funcionando é oq importa]

# entender e ver as notas do pdf
def extrair_texto_pdf(pdf_file):
    texto = []
    with pdfplumber.open(pdf_file) as pdf:
        for pagina in pdf.pages:
            conteudo = pagina.extract_text()
            if conteudo:
                texto.extend(conteudo.splitlines())
    return texto

# OCR (sla como essa porra funciona mas ta funcionando)
def extrair_texto_ocr(pdf_file):
    texto = []
    with pdfplumber.open(pdf_file) as pdf:
        for pagina in pdf.pages:
            pil_image = pagina.to_image(resolution=300).original
            pagina_texto = pytesseract.image_to_string(pil_image)
            if pagina_texto:
                texto.extend(pagina_texto.splitlines())
    return texto

# ver se é pdf ou imagen
def extrair_texto(pdf_file):
    texto = extrair_texto_pdf(pdf_file)
    if texto:
        return texto
    pdf_file.seek(0)
    return extrair_texto_ocr(pdf_file)

@app.route("/", methods=["GET", "POST"])
def index():
    gabarito, aluno = [], []
    if request.method == "POST":
        gabarito_pdf = request.files.get("gabarito")
        aluno_pdf = request.files.get("aluno")

        if gabarito_pdf:
            gabarito = extrair_texto(gabarito_pdf)
        if aluno_pdf:
            aluno = extrair_texto(aluno_pdf)

    return render_template("index.html", gabarito=gabarito or [], aluno=aluno or [])

if __name__ == "__main__":
    app.run(debug=True)
    
    render_template("index.html", gabarito=gabarito, aluno=aluno)

@app.route("/")
def index():
    # gabarito pra substituir pel pdf
    gabarito = ["A", "C", "B", "D", "A", "E"]
    aluno = ["A", "B", "B", "D", "C", "E"]

    # calculo de acertos
    acertos = sum(1 for i in range(len(gabarito))
                  if i < len(aluno) and aluno[i].upper() == gabarito[i].upper())

    # passa os bglh pra template
    return render_template("index.html", gabarito=gabarito, aluno=aluno, acertos=acertos)

if __name__ == "__main__":
    app.run(debug=True)

    
